MODUL PRAKTIKUM 01 - ANTAR JARINGAN

File utama: main.tex

Cara menggunakan di Overleaf:
1. Buat New Project -> Upload Project.
2. Upload file ZIP ini.
3. Pastikan main.tex dipilih sebagai Main document.
4. Compiler: pdfLaTeX.
5. Klik Recompile.

Tidak ada file eksternal yang wajib. Semua tabel dan worksheet sudah berada di main.tex.
