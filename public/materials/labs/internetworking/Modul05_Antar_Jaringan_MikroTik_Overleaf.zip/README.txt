MODUL PRAKTIKUM 05 - ANTAR JARINGAN

Upload seluruh isi ZIP ke Overleaf.
Main document: main.tex
Compiler: pdfLaTeX

Modul menggunakan TikZ untuk gambar topologi sehingga tidak membutuhkan file gambar eksternal.
Sebelum praktikum, instruktur harus memeriksa varian RB951 dan versi RouterOS. Bagian RIP utama menggunakan RouterOS v7.
