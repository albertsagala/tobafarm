Panduan Overleaf
1. Upload file 13S4121_M01_Pengantar_Keamanan_Siber_CIA_Triad_Beamer.tex ke Overleaf.
2. Pilih compiler pdfLaTeX.
3. Klik Recompile.
4. PDF yang dihasilkan adalah slide 16:9 untuk perkuliahan Minggu 1 Keamanan Siber.
