Cara compile di Overleaf:
1. Upload seluruh folder atau file ZIP ini ke Overleaf.
2. Pastikan compiler menggunakan pdfLaTeX.
3. Compile main.tex.
4. Output utama adalah main.pdf.
