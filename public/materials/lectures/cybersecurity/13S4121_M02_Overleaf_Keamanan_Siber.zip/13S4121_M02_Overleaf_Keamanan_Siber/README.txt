Panduan Overleaf
1. Upload seluruh isi folder ini ke Overleaf.
2. Buka file main.tex.
3. Pilih compiler pdfLaTeX.
4. Klik Recompile.
5. PDF yang dihasilkan adalah slide 16:9 untuk perkuliahan Minggu 2 Keamanan Siber.
