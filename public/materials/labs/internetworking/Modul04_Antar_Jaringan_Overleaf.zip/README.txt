MODUL PRAKTIKUM 04 - ANTAR JARINGAN
Dynamic Routing dengan RIP dan OSPF

Upload seluruh isi ZIP ke Overleaf.
Main document: main.tex
Compiler: pdfLaTeX

Topologi dibuat dengan TikZ sehingga tidak memerlukan file gambar eksternal.
